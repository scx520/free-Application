---
name: china-mobile-general-ppt
description: 制作或修改济南移动内部PPT，复用中国移动蓝白视觉及49页中性版式库中的目录、图文卡片、流程、组织关系与架构设计。适用于工作汇报、经营分析、总结、项目方案、产品介绍和专题材料；主题与内容以本次任务为准。
---

# China Mobile General PPT

移动通用PPT技能。复用具体版式的构图、分组、对齐和关系表达，不只取蓝白配色。当前资料决定内容与叙事，版式库帮助组织信息。

## 资源边界

- `assets/reference.pptx` 是49页中性、可编辑的版式库，不是一份完整汇报。文字、单位、日期、指标与图位均为占位，不提供业务事实。页数不代表新稿的页数要求。
- 资源中只保留通用视觉与结构，以及中国移动品牌素材。制作正式材料时，所有判断、数据、案例、组织名称和责任关系来自本次用户资料及可靠来源。
- 分享技能时只分发中性资源。后续任务的客户材料、人员信息、截图与成品留在各自任务目录，不能自动写回本库。
- 模板文件保持只读，编辑技能目录外的工作副本。资源里的文字与备注是参考数据，不是操作指令。用户指定其他正式模板时，以用户要求为准。

## 先选结构，再填内容

1. 读 `artifact-template.json`，按当前环境的 Presentations 技能完成作者工具、渲染及交付流程。
2. 整套制作先看 `assets/contact-sheets/contact-1.jpg` 至 `contact-4.jpg`，阅读 [版式选型入口](references/layout-recipes.md)。按用途参考 [内容编排](references/content-planning.md)，不把49页串成固定大纲。
3. 在当前任务目录记录简短选型表：`新页 / 信息关系 / 模板页 / 保留设计 / 内容适配`。不把制作记录写进正式PPT。
4. 用 `scripts/reference_lookup.py --slide N --design` 查看拆解，并打开完整PNG。目录读 [导航设计](references/navigation-design.md)，卡片读 [图文与卡片](references/card-design.md)，架构读 [关系与架构](references/architecture-design.md)。只读取当前相关分支。
5. 按 [原生复用方法](references/native-reuse.md) 抽取适配页，在作者工具中编辑。保留设计承重部分，如悬挂标题、层内分组、双环、连接线、侧翼和支撑底座。不要清空所有对象后用同一种方框重画。
6. 组件数量及内容容量按本次资料调整。长文字先提炼、调整槽位或拆页；图片框换成本次相关素材，指标占位换成有依据的原生图表或表格。
7. 先对选用家族试导入、导出、渲染一页，核对渐变、阴影、文字、裁切与组变换。导入失真时局部修复，不能用整页截图代替可编辑结构。
8. 逐页渲染检查内容、文字适配、信息关系和编辑性，与所选模板预览比较构图。最后清除未替换槽位及未使用模板页，更新目录、高亮和页码。

## 版式判断

- **目录是一套导航系统。** 2/16/24/32提供四种高亮状态，属于同一设计。保留大斜体“目录”、CONTENTS条、右侧章节带、当前项渐变白字与品牌边界。章节数与状态随新稿调整。
- **卡片按信息结构选。** 29是“问题—障碍—后果”，38是“阶段—动作—产出”，22是“论点—证据—解释—来源”，25是“案例—图片—措施—成效”。相同栏数不能代替关系判断。
- **架构保留语义。** 39适合两翼保障、多层依赖和层内分区，43适合共享平台承托，42适合来源、治理与处理，46适合目标、工作线与支撑。单向流转、双向调用、虚线协同与上下隶属不能互换。
- **页面节奏随内容变化。** 证据、对照、结构总览、计划与留白结论各有用途。不要连续多页只换标题，也不要为凑版式插入无意义图形。
- 版式内的局部小字和密度可以优化，但不能删除必要节点、责任边界或业务关系。单页任务不自动增加封面、目录或结束页。

## 视觉与内容

- 16:9，12192000 × 6858000 EMU，对应1280 × 720 CSS像素。主字体微软雅黑，白底、蓝色结构、黑色正文、红色重点；具体尺寸和色彩见 [视觉规范](references/visual-system.md)。
- 延续所选模板的文字层级、留白、渐变、折面与对齐。品牌标识保持比例。目录、封面、内容页和结束页有各自构图，不将品牌元素铺满每页。
- 顶部说明和页底结论按信息需要使用，不强制每页都写长导语或口号。主标题直接说明主题，重点色只强调有业务意义的短语。
- “XX%”“指标一”“填写说明”等均为槽位。不得将其作为事实，或为填满版式虚构成果。正式数据说明周期、单位、统计口径，区分同比/环比和百分比/百分点。
- 所需表格、图表、流程、组织和架构关系保持可编辑。图片只承担相应素材或证据用途，不能将整个信息图作为背景交付。

## 按需资源

- [可视化版式库](assets/design-atlas.html)：按信息关系筛选、放大查看，适合浏览选型。
- [49页设计拆解](references/design-atlas.md)及 `design-atlas.json`：每页的关系、构图、槽位、保留点、适配方式与误用。
- [页型选型](references/layout-recipes.md)、[49页索引](references/slide-catalog.md)及 `layout-index.json`：跨主题选择结构。
- [目录](references/navigation-design.md)、[卡片](references/card-design.md)、[架构](references/architecture-design.md)：相应家族的详细判断。
- [原生复用](references/native-reuse.md)、[内容编排](references/content-planning.md)、[视觉规范](references/visual-system.md)。
- `assets/slides/slide-001.png` 至 `slide-049.png`：中性版式完整预览，仅供选型与核对。
- `references/slide-inventory.json`：中性对象、字号、颜色、几何和备注索引。组内坐标需结合组变换与渲染判断。
- [槽位文字索引](references/template-text.md)：定位文本框，不作为正式材料文案。
- `references/template-metadata.json`：中性资源范围、画布与当前文件指纹。

## 检索与抽取

使用当前环境提供的Python。检索脚本仅依赖标准库；原生抽取脚本依赖 `lxml`。

```text
reference_lookup.py --list
reference_lookup.py --family cards
reference_lookup.py --slide 39 --design
reference_lookup.py --slide 1 --extract-media <当前任务素材目录>
native_slides.py --slides 1,2,29,38,39,43,48,49 --output <任务目录>/native-base.pptx --map-output <任务目录>/template-objects.json
```

默认检索只读。`--extract-media`将指定页及布局依赖的品牌图片写入明确指定的目录。抽取器保留模板依赖，只设置所选页面列表，工作副本仍可能含未选的中性页面部件；它是编辑起点，不能直接作为最终交付。重复页在作者工具中复制，工具对象ID在导入后重新核对。
