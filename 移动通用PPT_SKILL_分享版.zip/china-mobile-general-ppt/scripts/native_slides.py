"""Extract selected reference slides unchanged, with their native dependencies.

This selects and packages source pages; it does not author new presentation content.
Use the current Presentations workflow to edit the resulting working copy.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import posixpath
import sys
import tempfile
from lxml import etree as ET
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
P = 'http://schemas.openxmlformats.org/presentationml/2006/main'
A = 'http://schemas.openxmlformats.org/drawingml/2006/main'
R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
PK = 'http://schemas.openxmlformats.org/package/2006/relationships'
CT = 'http://schemas.openxmlformats.org/package/2006/content-types'
NS = {'p': P, 'a': A, 'r': R}

def serialize(element):
    # lxml preserves namespace declarations referenced in mc:Ignorable and
    # Requires attribute values. ElementTree silently drops these declarations.
    return ET.tostring(element, encoding='utf-8', xml_declaration=True)

def relpart(part):
    return posixpath.join(posixpath.dirname(part), '_rels', posixpath.basename(part)+'.rels') if part else '_rels/.rels'

def target_part(part, target):
    return target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join(posixpath.dirname(part), target))

def slide_parts(data):
    relationships = ET.fromstring(data['ppt/_rels/presentation.xml.rels'])
    targets = {r.get('Id'): target_part('ppt/presentation.xml', r.get('Target')) for r in relationships}
    doc = ET.fromstring(data['ppt/presentation.xml'])
    return [targets[s.get('{'+R+'}id')] for s in doc.find('p:sldIdLst', NS)]

def objects(data, part):
    """Record native object identity, ancestry, local transforms and rich text.

    Coordinates inside groups are intentionally left local. The exact group
    transform is included instead of incorrectly treating local values as pixels.
    """
    result = []
    tree = ET.fromstring(data[part]).find('p:cSld/p:spTree', NS)
    def walk(parent, ancestry):
        for node in parent:
            kind = node.tag.split('}')[-1]
            if kind not in ('sp', 'grpSp', 'pic', 'graphicFrame', 'cxnSp'):
                continue
            nv = node.find('./p:nvGrpSpPr/p:cNvPr', NS) if kind == 'grpSp' else None
            if nv is None:
                for candidate in list(node):
                    nv = candidate.find('p:cNvPr', NS)
                    if nv is not None:
                        break
            identity = nv.get('id') if nv is not None else None
            name = nv.get('name', '') if nv is not None else ''
            xfrm = None
            for xpath in ('p:grpSpPr/a:xfrm', 'p:spPr/a:xfrm', 'p:xfrm'):
                xfrm = node.find(xpath, NS)
                if xfrm is not None:
                    break
            transform = None if xfrm is None else {
                **xfrm.attrib,
                **{child.tag.split('}')[-1]: dict(child.attrib) for child in xfrm}
            }
            texts = []
            # Exclude descendant group text from the group record itself.
            text_root = node.find('p:txBody', NS)
            if text_root is not None:
                for paragraph in text_root.findall('a:p', NS):
                    texts.append(''.join(t.text or '' for t in paragraph.findall('.//a:t', NS)))
            if kind == 'graphicFrame':
                texts = [''.join(t.text or '' for t in cell.findall('.//a:t', NS)) for cell in node.findall('.//a:tc', NS)]
            runs = []
            if text_root is not None:
                for run in text_root.findall('.//a:r', NS):
                    prop = run.find('a:rPr', NS)
                    runs.append({'text': ''.join(t.text or '' for t in run.findall('a:t', NS)),
                                 'properties': ET.tostring(prop, encoding='unicode') if prop is not None else None})
            item = {'source_id': identity, 'name': name, 'type': kind, 'group_path': ancestry,
                    'transform_emu': transform, 'text': '\n'.join(texts), 'runs': runs}
            geom = node.find('p:spPr/a:prstGeom', NS)
            if geom is not None:
                item['preset'] = geom.get('prst')
            result.append(item)
            if kind == 'grpSp':
                walk(node, ancestry+[identity])
    walk(tree, [])
    return result

def select_slides(source, selected, output, map_output=None):
    """Build a source-compatible working copy by changing only page selection.

    Retaining original package parts avoids breaking PowerPoint's proprietary
    extension data. This is preparation, not a sanitized final deliverable.
    """
    source = source.resolve()
    output = Path(output).resolve()
    destinations = [output] + ([Path(map_output).resolve()] if map_output else [])
    if len(set(destinations)) != len(destinations):
        raise ValueError('Output and object map must be separate files.')
    for path in destinations:
        if path == source or ROOT.resolve() in path.parents:
            raise ValueError('Outputs must be task working copies outside the installed skill.')
        if path.exists():
            raise FileExistsError(f'Refusing to overwrite {path}')
    if output.suffix.lower() != '.pptx':
        raise ValueError('Output must end in .pptx')
    if len(set(selected)) != len(selected):
        raise ValueError('Select each source slide once; duplicate the imported page in the authoring tool when needed.')
    with ZipFile(source) as z:
        data = {n: z.read(n) for n in z.namelist()}
    originals = slide_parts(data)
    if not selected or any(n < 1 or n > len(originals) for n in selected):
        raise ValueError('Slide numbers must be within the source deck.')
    pres = ET.fromstring(data['ppt/presentation.xml'])
    ids = pres.find('p:sldIdLst', NS)
    source_ids = list(ids)
    for node in list(ids):
        ids.remove(node)
    for number in selected:
        ids.append(source_ids[number-1])
    # Old custom shows/section metadata refer to the original order.
    for node in list(pres):
        if node.tag in ['{'+P+'}custShowLst', '{'+P+'}extLst']:
            pres.remove(node)
    data['ppt/presentation.xml'] = serialize(pres)
    mapping = []
    for index, number in enumerate(selected, 1):
        part = originals[number-1]
        mapping.append({'output_slide':index, 'source_slide':number,
                        'source_part':part,
                        'source_xml_sha256':hashlib.sha256(data[part]).hexdigest(),
                        'objects':objects(data,part)})
    output.parent.mkdir(parents=True,exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.native-slides-',suffix='.pptx',dir=output.parent)
    os.close(fd)
    try:
        with ZipFile(temporary,'w',ZIP_DEFLATED) as dst:
            for name, content in data.items():
                dst.writestr(name,content)
        os.replace(temporary,output)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    if map_output:
        dest = Path(map_output)
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_text(json.dumps({'source':str(source),'slides':mapping},ensure_ascii=False,indent=2),encoding='utf-8')
    return {'output':str(output),'source_slides':selected,'slide_count':len(selected),
            'native_slide_xml_unchanged':True,'bytes':output.stat().st_size,
            'working_copy_only':'Neutral template notes and unlisted template parts retained; edit and export only the requested pages.'}

def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--slides', required=True, help='One-based ordered numbers, e.g. 1,2,29,38,39; unique source pages only')
    ap.add_argument('--output', required=True, help='New .pptx in the task workspace')
    ap.add_argument('--map-output', help='Optional source object map in task workspace')
    args = ap.parse_args()
    manifest = json.loads((ROOT/'artifact-template.json').read_text(encoding='utf-8'))
    selected = [int(n.strip()) for n in args.slides.split(',')]
    result = select_slides(ROOT/manifest['reference'], selected, args.output, args.map_output)
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
