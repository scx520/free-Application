"""Look up generic Jinan Mobile PPT layouts and optionally extract original assets."""
import argparse
import json
from pathlib import Path
import posixpath
import sys
from xml.etree import ElementTree as ET
from zipfile import ZipFile

SKILL_DIR = Path(__file__).resolve().parents[1]
REL_NS = '{http://schemas.openxmlformats.org/package/2006/relationships}'

def extract_media(reference, slide_part, dest):
    found = []
    seen = set()
    queue = [slide_part]
    dest = Path(dest).resolve()
    dest.mkdir(parents=True, exist_ok=True)
    with ZipFile(reference) as z:
        names = set(z.namelist())
        while queue:
            part = queue.pop()
            if part in seen:
                continue
            seen.add(part)
            relpart = posixpath.join(posixpath.dirname(part), '_rels', posixpath.basename(part)+'.rels')
            if relpart not in names:
                continue
            for rel in ET.fromstring(z.read(relpart)).findall(REL_NS+'Relationship'):
                if rel.get('TargetMode') == 'External':
                    continue
                raw_target = rel.get('Target','')
                target = raw_target.lstrip('/') if raw_target.startswith('/') else posixpath.normpath(posixpath.join(posixpath.dirname(part), raw_target))
                if target not in names:
                    continue
                if rel.get('Type','').endswith(('/slideLayout','/slideMaster')):
                    queue.append(target)
                if rel.get('Type','').endswith('/image') and target.startswith('ppt/media/'):
                    data = z.read(target)
                    targetfile = dest / posixpath.basename(target)
                    if targetfile.exists() and targetfile.read_bytes() != data:
                        raise FileExistsError(f'Refusing to overwrite different asset: {targetfile}')
                    if not targetfile.exists():
                        targetfile.write_bytes(data)
                    if str(targetfile) not in found:
                        found.append(str(targetfile))
    return found

def main():
    if hasattr(sys.stdout,'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    ap = argparse.ArgumentParser(description=__doc__)
    group = ap.add_mutually_exclusive_group(required=True)
    group.add_argument('--list', action='store_true')
    group.add_argument('--query', help='Case-insensitive literal text search')
    group.add_argument('--slide', type=int, help='One-based slide number')
    group.add_argument('--family', help='Design family ID or Chinese name, e.g. cards / 架构体系')
    ap.add_argument('--design', action='store_true', help='Compact deep design analysis for --slide')
    ap.add_argument('--extract-media', metavar='DIRECTORY', help='Write original local images for --slide, including its layout/master images')
    args = ap.parse_args()
    if args.extract_media and args.slide is None:
        ap.error('--extract-media requires --slide')
    if args.design and args.slide is None:
        ap.error('--design requires --slide')
    manifest = json.loads((SKILL_DIR/'artifact-template.json').read_text(encoding='utf-8'))
    inventory = json.loads((SKILL_DIR/'references/slide-inventory.json').read_text(encoding='utf-8'))
    layout_path = SKILL_DIR/'references/layout-index.json'
    layouts = {row['slide']:row for row in json.loads(layout_path.read_text(encoding='utf-8'))['slides']} if layout_path.exists() else {}
    atlas = json.loads((SKILL_DIR/'references/design-atlas.json').read_text(encoding='utf-8'))
    designs = {row['slide']:row for row in atlas['slides']}
    if args.family:
        reverse = {v:k for k,v in atlas['families'].items()}
        args.family = reverse.get(args.family, args.family)
        if args.family not in atlas['families']:
            ap.error('Unknown family. Choose: '+', '.join(atlas['families']))
    rows = inventory['slides']
    if args.slide is not None:
        if not 1 <= args.slide <= len(rows):
            ap.error(f'--slide must be between 1 and {len(rows)}')
        source_row = rows[args.slide-1]
        row = dict(designs[args.slide]) if args.design else dict(source_row)
        if not args.design:
            row['layout'] = layouts.get(args.slide,{})
            row['design'] = designs.get(args.slide,{})
        row['preview'] = str(SKILL_DIR/'assets/slides'/f"slide-{args.slide:03d}.png")
        if args.extract_media:
            row['extracted_media'] = extract_media(SKILL_DIR/manifest['reference'],source_row['part'],args.extract_media)
        print(json.dumps(row,ensure_ascii=False,indent=2))
        return
    for row in rows:
        design = designs.get(row['slide'],{})
        if args.family and args.family not in design.get('families',[]):
            continue
        layout = layouts.get(row['slide'],{})
        layout_text = ' / '.join([layout.get('layout_name',''),layout.get('structure',''),'、'.join(layout.get('use_cases',[]))])
        if args.query and args.query.casefold() not in (layout_text+' '+row['text']+' '+json.dumps(design,ensure_ascii=False)).casefold():
            continue
        text = ' / '.join(x.strip() for x in row['text'].splitlines() if x.strip())
        if design:
            snippet = design['title']+' / '+design['relation']+' / '+design['composition']
        elif layout:
            snippet = layout_text
        elif args.query:
            hit = text.casefold().find(args.query.casefold())
            start = max(0,hit-60)
            snippet = text[start:start+240]
        else:
            snippet = text[:170]
        print(f"{row['slide']:03d} {snippet}")

if __name__ == '__main__':
    main()
